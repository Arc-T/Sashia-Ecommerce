package com.sashia.ecommerce.media;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;
import java.util.Map;

@Getter
@Setter
@Entity
@Table(name = "media", schema = "media")
public class Media {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String slug;

    private String checksum;

    @Enumerated(EnumType.STRING)
    private MediaResourceType resourceType;

    @Enumerated(EnumType.STRING)
    private MediaStatus status;

    private Long resourceId;

    private String mimeType;

    private String extension;

    private Long size;

    @JdbcTypeCode(SqlTypes.JSON)
    private Map<String, Object> metadata;

    private String description;

    @CreationTimestamp
    private LocalDateTime createdAt;

    /* ****************************** GETTER & SETTERS ******************************** */

}
